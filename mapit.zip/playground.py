from dash import Dash, html, Input, Output, ClientsideFunction, State
import dash_cytoscape as cyto

app = Dash(__name__)

app.layout = html.Div([
    cyto.Cytoscape(
        id='cyto-graph',
        elements=[
            {'data': {'id': 'a', 'label': 'Node A'}, 'position': {'x': 75, 'y': 75}},
            {'data': {'id': 'b', 'label': 'Node B'}, 'position': {'x': 200, 'y': 200}},
            {'data': {'source': 'a', 'target': 'b'}}
        ],
        style={'width': '400px', 'height': '400px'}
    ),
    html.Button('Download Graph Image', id='download-button'),
    html.A(id='download', style={'display': 'none'})
])

# Client-side callback to download the graph image
app.clientside_callback(
    ClientsideFunction(
        namespace='clientside',
        function_name='exportGraphImage'
    ),
    Output('download', 'href'),
    Input('download-button', 'n_clicks'),
    State('cyto-graph', 'id')
)

if __name__ == '__main__':
    app.run_server(debug=True)
